package com.dash.production;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashProductionApplicationTests {

	@Test
	void contextLoads() {
	}

}
